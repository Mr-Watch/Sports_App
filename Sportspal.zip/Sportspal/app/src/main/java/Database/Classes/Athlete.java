package Database.Classes;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "athletes_table", foreignKeys = @ForeignKey(entity = Sport.class,
        parentColumns = "sport_id",
        childColumns = "athlete_sport_id",
        onDelete = ForeignKey.SET_NULL),
        indices = {@Index(value = {"athlete_surname"}, unique = true)})

public class Athlete {

    @PrimaryKey
    @ColumnInfo(name = "athlete_id")
    public int athleteId;
    @ColumnInfo(name = "athlete_first_name")
    public String athleteFirstName;
    @ColumnInfo(name = "athlete_surname")
    public int athleteSurname;
    @ColumnInfo(name = "athlete_city")
    public int athleteCity;
    @ColumnInfo(name = "athlete_country")
    public int athleteCountry;
    @ColumnInfo(name = "athlete_sport_id")
    public int athleteSportId;
    @ColumnInfo(name = "athlete_birth_year")
    public int athleteBirthYear;

    public Athlete(int athleteId,
                   String athleteFirstName,
                   int athleteSurname,
                   int athleteCity,
                   int athleteCountry,
                   int athleteSportId,
                   int athleteBirthYear) {
        this.athleteId = athleteId;
        this.athleteFirstName = athleteFirstName;
        this.athleteSurname = athleteSurname;
        this.athleteCity = athleteCity;
        this.athleteCountry = athleteCountry;
        this.athleteSportId = athleteSportId;
        this.athleteBirthYear = athleteBirthYear;
    }

    public int getAthleteId() {
        return athleteId;
    }

    public void setAthleteId(int athleteId) {
        this.athleteId = athleteId;
    }

    public String getAthleteFirstName() {
        return athleteFirstName;
    }

    public void setAthleteFirstName(String athleteFirstName) {
        this.athleteFirstName = athleteFirstName;
    }

    public int getAthleteSurname() {
        return athleteSurname;
    }

    public void setAthleteSurname(int athleteSurname) {
        this.athleteSurname = athleteSurname;
    }

    public int getAthleteCity() {
        return athleteCity;
    }

    public void setAthleteCity(int athleteCity) {
        this.athleteCity = athleteCity;
    }

    public int getAthleteCountry() {
        return athleteCountry;
    }

    public void setAthleteCountry(int athleteCountry) {
        this.athleteCountry = athleteCountry;
    }

    public int getAthleteSportId() {
        return athleteSportId;
    }

    public void setAthleteSportId(int athleteSportId) {
        this.athleteSportId = athleteSportId;
    }

    public int getAthleteBirthYear() {
        return athleteBirthYear;
    }

    public void setAthleteBirthYear(int athleteBirthYear) {
        this.athleteBirthYear = athleteBirthYear;
    }
}
