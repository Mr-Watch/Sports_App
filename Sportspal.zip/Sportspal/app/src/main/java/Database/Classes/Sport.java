package Database.Classes;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "sports_table",
        indices = {@Index(value = {"sport_name",
                "sport_type",
                "sport_gender"},
                unique = true)})

public class Sport {

    @PrimaryKey
    @ColumnInfo(name = "sport_id")
    public int sportId;
    @ColumnInfo(name = "sport_name")
    public String sportName;
    @ColumnInfo(name = "sport_type")
    public int sportType;
    @ColumnInfo(name = "sport_gender")
    public int sportGender;

    public Sport(int sportId,
                 String sportName,
                 int sportType,
                 int sportGender) {
        this.sportId = sportId;
        this.sportName = sportName;
        this.sportType = sportType;
        this.sportGender = sportGender;
    }

    public int getSportId() {
        return sportId;
    }

    public void setSportId(int sportId) {
        this.sportId = sportId;
    }

    public String getSportName() {
        return sportName;
    }

    public void setSportName(String sportName) {
        this.sportName = sportName;
    }

    public int getSportType() {
        return sportType;
    }

    public void setSportType(int sportType) {
        this.sportType = sportType;
    }

    public int getSportGender() {
        return sportGender;
    }

    public void setSportGender(int sportGender) {
        this.sportGender = sportGender;
    }
}
