package Database.Interfaces;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Update;

import Database.Classes.Athlete;

@Dao
public interface AthleteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAthlete(Athlete... athletes);

    @Delete
    void deleteAthlete(Athlete... athletes);

    @Update
    void updateAthlete(Athlete... athletes);
}
