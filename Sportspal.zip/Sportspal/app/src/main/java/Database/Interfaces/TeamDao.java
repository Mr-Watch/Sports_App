package Database.Interfaces;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Update;

import Database.Classes.Team;

@Dao
public interface TeamDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertTeam(Team... teams);

    @Delete
    void deleteTeam(Team... teams);

    @Update
    void updateTeam(Team... teams);
}
