package Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sportspal.R;

import java.util.ArrayList;
import java.util.List;

import Database.Classes.Sport;

public class SportAdapter extends RecyclerView.Adapter<SportAdapter.SportHolder> {
    private List<Sport> sports = new ArrayList<>();

    @NonNull
    @Override
    public SportHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sport_recyclerview_item, parent, false);
        return new SportHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SportHolder holder, int position) {
        String gender = "";
        Sport currentSport = sports.get(position);
        holder.textViewSportName.setText(currentSport.getSportName());
        switch (currentSport.getSportGender()) {
            case 0:
                gender = "Male";
                break;
            case 1:
                gender = "Female";
                break;
            default:
                gender = "N/A";
                break;
        }
        holder.textViewSportGender.setText(gender);
    }

    @Override
    public int getItemCount() {
        return sports.size();
    }

    public void setSports(List<Sport> sports) {
        this.sports = sports;
        notifyDataSetChanged();
    }

    class SportHolder extends RecyclerView.ViewHolder {
        private TextView textViewSportName;
        private TextView textViewSportGender;


        public SportHolder(@NonNull View itemView) {
            super(itemView);
            textViewSportName = itemView.findViewById(R.id.sport_name);
            textViewSportGender = itemView.findViewById(R.id.sport_gender);
        }
    }
}
