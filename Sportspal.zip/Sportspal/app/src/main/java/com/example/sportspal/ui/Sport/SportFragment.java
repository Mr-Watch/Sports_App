package com.example.sportspal.ui.Sport;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sportspal.R;

import java.util.List;

import Adapters.SportAdapter;
import Database.Classes.Sport;

public class SportFragment extends Fragment {

    private SportViewModel sportViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        sportViewModel =
                new ViewModelProvider(this).get(SportViewModel.class);
        View root = inflater.inflate(R.layout.fragment_sport, container, false);
        RecyclerView sportRecyclerView = root.findViewById(R.id.sport_recyclerview);
        sportRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        sportRecyclerView.setHasFixedSize(true);

        SportAdapter sportAdapter = new SportAdapter();
        sportRecyclerView.setAdapter(sportAdapter);

        sportViewModel.getAllSports().observe(getViewLifecycleOwner(), new Observer<List<Sport>>() {
            @Override
            public void onChanged(List<Sport> sports) {
                sportAdapter.setSports(sports);
            }
        });
        return root;
    }
}